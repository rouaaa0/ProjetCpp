/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QTabWidget *ajouet;
    QWidget *tab;
    QGroupBox *groupBox;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLineEdit *id_trajet;
    QLineEdit *temps;
    QLineEdit *distance;
    QLineEdit *emplacement;
    QLineEdit *prix;
    QPushButton *pb_ajouter;
    QWidget *tab_3;
    QTableWidget *tableWidget;
    QLabel *label_6;
    QLineEdit *le_id_supp;
    QPushButton *supp;
    QWidget *tab_2;
    QTableView *tab_trajet;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(800, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        ajouet = new QTabWidget(centralwidget);
        ajouet->setObjectName(QStringLiteral("ajouet"));
        ajouet->setGeometry(QRect(30, 30, 681, 371));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        groupBox = new QGroupBox(tab);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(10, 20, 651, 311));
        label = new QLabel(groupBox);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 60, 47, 14));
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(20, 100, 47, 14));
        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(20, 140, 47, 14));
        label_4 = new QLabel(groupBox);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(10, 190, 71, 16));
        label_5 = new QLabel(groupBox);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(20, 240, 47, 14));
        id_trajet = new QLineEdit(groupBox);
        id_trajet->setObjectName(QStringLiteral("id_trajet"));
        id_trajet->setGeometry(QRect(90, 60, 113, 20));
        temps = new QLineEdit(groupBox);
        temps->setObjectName(QStringLiteral("temps"));
        temps->setGeometry(QRect(90, 100, 113, 20));
        distance = new QLineEdit(groupBox);
        distance->setObjectName(QStringLiteral("distance"));
        distance->setGeometry(QRect(90, 140, 113, 20));
        emplacement = new QLineEdit(groupBox);
        emplacement->setObjectName(QStringLiteral("emplacement"));
        emplacement->setGeometry(QRect(90, 190, 113, 20));
        prix = new QLineEdit(groupBox);
        prix->setObjectName(QStringLiteral("prix"));
        prix->setGeometry(QRect(90, 240, 113, 20));
        pb_ajouter = new QPushButton(groupBox);
        pb_ajouter->setObjectName(QStringLiteral("pb_ajouter"));
        pb_ajouter->setGeometry(QRect(420, 260, 75, 23));
        ajouet->addTab(tab, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        tableWidget = new QTableWidget(tab_3);
        tableWidget->setObjectName(QStringLiteral("tableWidget"));
        tableWidget->setGeometry(QRect(0, -10, 661, 361));
        label_6 = new QLabel(tab_3);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(20, 40, 47, 14));
        le_id_supp = new QLineEdit(tab_3);
        le_id_supp->setObjectName(QStringLiteral("le_id_supp"));
        le_id_supp->setGeometry(QRect(100, 70, 113, 20));
        supp = new QPushButton(tab_3);
        supp->setObjectName(QStringLiteral("supp"));
        supp->setGeometry(QRect(330, 140, 75, 23));
        ajouet->addTab(tab_3, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        tab_trajet = new QTableView(tab_2);
        tab_trajet->setObjectName(QStringLiteral("tab_trajet"));
        tab_trajet->setGeometry(QRect(-5, 1, 681, 361));
        ajouet->addTab(tab_2, QString());
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 22));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        ajouet->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("MainWindow", "Ajout", Q_NULLPTR));
        label->setText(QApplication::translate("MainWindow", "Id_trajet", Q_NULLPTR));
        label_2->setText(QApplication::translate("MainWindow", "Temps", Q_NULLPTR));
        label_3->setText(QApplication::translate("MainWindow", "Distance", Q_NULLPTR));
        label_4->setText(QApplication::translate("MainWindow", "Emplacement", Q_NULLPTR));
        label_5->setText(QApplication::translate("MainWindow", "Prix", Q_NULLPTR));
        pb_ajouter->setText(QApplication::translate("MainWindow", "Ajouter", Q_NULLPTR));
        ajouet->setTabText(ajouet->indexOf(tab), QApplication::translate("MainWindow", "ajouter un itin\303\251raire", Q_NULLPTR));
        label_6->setText(QApplication::translate("MainWindow", "supprimer", Q_NULLPTR));
        supp->setText(QApplication::translate("MainWindow", "supprimer", Q_NULLPTR));
        ajouet->setTabText(ajouet->indexOf(tab_3), QApplication::translate("MainWindow", "supprimer un itin\303\251raire", Q_NULLPTR));
        ajouet->setTabText(ajouet->indexOf(tab_2), QApplication::translate("MainWindow", "afficher un itin\303\251raire", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
